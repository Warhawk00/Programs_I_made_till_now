from turtle import Turtle, Screen
import random
t = Turtle()
t.shape("circle")
screen = Screen()
t.pensize(15)
t.speed(0)
screen.colormode(255)
direction = [0, 90, 180, 270]


def random_color(t):
    red = random.randint(0, 255)
    green = random.randint(0, 255)
    blue = random.randint(0, 255)
    return t.color(red, blue, green)


for _ in range(200):
    random_color(t)
    r = random.randint(1, 4)
    t.setheading(random.choice(direction))
    t.fd(30)
screen.exitonclick()
