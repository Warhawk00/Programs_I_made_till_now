import turtle as t
import random as r

turtle = t.Turtle()
screen = t.Screen()
screen.colormode(255)
screen.bgcolor("black")


def random_color():
    red = r.randint(0, 255)
    green = r.randint(0, 255)
    blue = r.randint(0, 255)
    return red, blue, green


turtle.width(2)
turtle.speed(0)


def size_of_pattern(size):
    for i in range(round(360 / size)):
        color = random_color()
        turtle.color(color)
        turtle.pencolor(color)
        turtle.setheading(turtle.heading() + size)
        turtle.circle(100)


size_of_pattern(1)
screen.exitonclick()
