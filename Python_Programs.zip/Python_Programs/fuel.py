#making fuel
i = 1
while i == 1:
    try:
        f = eval(input("Fraction: "))
        if f<1 and f>=0:
            p = int(round(f,2)*100)
            i = 0
            if p<1:
                print("E")
            elif p>99:
                print("F")
            else:
                print(p,"%")
        else:
            i = 1
    except:
        i = 1
    