# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 16:20:19 2023

@author: rudra
 problem set 3 que name - Grocery
"""
l = []
while True:
    try:
        i = input()
        item = i.capitalize()
        l.append(item)
    except EOFError:
        l1 =[]
        l.sort()
        print(l)
        for i in l:
            if i not in l1:
                l1.append(i)
        for e in l1:
            print(l.count(e), e)
