
class QuizBrain:

    def __init__(self, q_list):
        self.question_no = 0
        self.q_list = q_list
        self.score = 0

    def ques_still_remain(self):
        return self.question_no < len(self.q_list)

    def next_question(self):
        current_que = self.q_list[self.question_no]
        user_answer  = input(f"Q{self.question_no+1}. {current_que.text} (True/False)? ")
        self.question_no += 1
        self.check_answer(user_answer, current_que.answer)

    def check_answer(self, user_answer, correct_answer ):
        if user_answer.lower() == correct_answer.lower():
            print("You got it right")
            self.score += 1
        else:
            print("Sorry It's wrong")
        print(f"The correct answer was {correct_answer} ")
        print(f"Your score is {self.score}/{self.question_no}")
        print("\n")
