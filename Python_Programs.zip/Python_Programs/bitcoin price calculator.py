import requests
import json
import sys

while True:
    try:
        o = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
        j = o.json()
        for i in j["bpi"].values():
            if i["code"] == "USD":
                price= i["rate_float"]*sys.argv()
                sys.exit()
    except SystemExit:
      print(round(price,2))
      print("EX")
      sys.exit()
    else:
        print("AS")
        pass
    