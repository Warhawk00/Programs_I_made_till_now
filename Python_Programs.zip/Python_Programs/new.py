date = input("Date: ")
date_1 = date.split("/")
month = date_1[0]
day = date_1[1]
year = date_1[2]
if int(day)>=0 and int(day)<=31 and 12>=int(month)>=0:
    print(f"{year}", f"{month:02}", f"{day:02}",sep = "-")