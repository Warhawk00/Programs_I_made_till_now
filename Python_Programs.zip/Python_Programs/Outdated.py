# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 21:23:48 2023

@author: MAA
"""
while True:
    try:
        date = input("Date: ")
        date_1 = date.split("/")
        if len(date_1) == 3: 
            month = int(date_1[0])
            day = int(date_1[1])
            year = int(date_1[2])
            if 0 <= day <= 31 and 0 <= month <= 12:
                print(f"{year}", f"{month:02}", f"{day:02}",sep = "-")
                break

        months = [

            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
            ]

        date = date.replace(","," ")
        date_2 = date.split()
        if len(date_2) == 3:
            m = date_2[0].title()
            if m in months:
                month = months.index(m)+1
                day = int(date_2[1])
                year = date_2[2]
                if 0 <= day <= 31 and 0 <= month <= 12:
                    print(f"{year}", f"{month:02}", f"{day:02}",sep = "-")
                    break
    except:
        continue