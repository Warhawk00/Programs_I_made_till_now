import PySimpleGUI as gui
layout = [[gui.Text("Hello world")] , [gui.Button("OK")]]
gui.Window(title= "Test", layout=layout, margins=(100,50), background_color="darkgreen").read()


