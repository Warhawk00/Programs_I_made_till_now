MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "coffee": 18,
        },
        "cost": 150,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 250,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 300,
    }
}


resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
}
money = 0
ON = True


def check_resources2(coffee):
    """Tells if resources are sufficient"""
    for ingredient in MENU[coffee]["ingredients"]:
        if resources[ingredient] < MENU[coffee]["ingredients"][ingredient]:
            print(f"{ingredient} is not enough")
            return False
        else:
            return True


print('''" Coffee     :    Cost
    espresso :   150
    latte        :    250
    cappuccino : 300
    commands - type 'report' to report status of machine
                     - type 'off' to  turn off the machine''' )
while ON:
    user_input = input("What would you like? (espresso/latte/cappuccino): ").lower()
    if user_input == "report":
        print(f"Water: {resources['water']}ml\nMilk : {resources['milk']}ml\nCoffee : {resources['coffee']}g\nMoney : ₹{money}")
    elif user_input in ("latte", "espresso", "cappuccino"):
        if check_resources2(user_input):
            print("Please insert coins")
            coin_20 = int(input("How many ₹20 coin?💰: "))
            coin_10 = int(input("How many ₹10 coin?💰: "))
            coin_5 = int(input("How many ₹5 coin?💰: "))
            coin_2 = int(input("How many ₹2 coin?💰: "))
            total_money = coin_20 * 20 + coin_10 * 10 + coin_5 * 5 + coin_2 * 2
            cost = MENU[user_input]["cost"]
            if total_money >= cost:
                refund_money = total_money - cost
                money = money + cost
                print(f"Here {refund_money} 💰 is rupees in change")
                print(f"Here is your {user_input} ☕ Enjoy!")
                for ingredient in MENU[user_input]["ingredients"]:
                    resources[ingredient] = resources[ingredient] - MENU[user_input]["ingredients"][ingredient]
            else:
                print("Sorry that's not enough money. Money refunded.💰")
    elif user_input == "off":
        ON = False
