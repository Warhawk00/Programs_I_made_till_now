import random
cards = [
    11,2,3,4,5,6,7,8,9,10,10,10,10
]
game_ends = False

card_of_player = random.sample(cards,2)
card_of_com = random.sample(cards,2)
draw ="n"
 
while True:
    print(f"Card of player : {card_of_player} your score: {sum(card_of_player)}\nFirst Card of computer: {card_of_com[0]}")
    score_of_player = sum(card_of_player)
    score_of_com = sum(card_of_com)
    if score_of_com == score_of_player and draw != "y":
        print("Draw")
        print(f"Card of player : {card_of_player} your score: {sum(card_of_player)}\n Card of computer: {card_of_com}")
        break
    if score_of_player == 21 or score_of_com == 21:
        if score_of_com == 21:
            print(f"Computer Won Card of computer : {card_of_com}")
            break
        else:
            print(f"You won Your final card: {card_of_player} your score:{sum(card_of_player)}\nCard of computer: {card_of_com}")
            break
    if score_of_player >21:
        if 11 in card_of_player:
            i = card_of_player.index(11)
            card_of_player[i] = 1
        else:
            print(f"Computer Won Card of computer : {card_of_com}")
            break
    elif score_of_com>21:
        if 11 in card_of_com:
            i = card_of_com.index(11)
            card_of_com[i] = 1
        else:
            print(f"You won Your final card: {card_of_player} your score:{sum(card_of_player)}\nCard of computer: {card_of_com}")
            break
    
    
    if score_of_player <21:
        draw = input("Do you want to draw a card? y/n: ")
        if draw == "y":
            card_of_player.append(random.choice(cards))
        elif draw == "n" and score_of_com>17:
            if score_of_com>score_of_player:
                print(f"Computer Won Card of computer:{card_of_com} your score:{sum(card_of_player)}")
                break
            elif score_of_com<score_of_player:
                print(f"You won Your final card: {card_of_player} your score:{sum(card_of_player)}\nCard of computer: {card_of_com}")
                break
    if score_of_com<17:
        card_of_com.append(random.choice(cards))
input()

    
