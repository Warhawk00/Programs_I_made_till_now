# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 15:48:35 2023

@author: Rudra

CS50p que practice set 3 name -felipe's tequeria
"""
menu = {
    "baja taco": 4.25,
    "burrito": 7.50,
    "bowl": 8.50,
    "nachos": 11.00,
    "quesadilla": 8.50,
    "super burrito": 8.50,
    "super quesadilla": 9.50,
    "taco": 3.00,
    "tortilla salad": 8.00
}
total = 0
while True:
    try:
        i = input("Item: ")
        i = i.lower()
        if i in menu:
            total = total + menu[i]
            print("Total: ", total)
    except EOFError:
        break