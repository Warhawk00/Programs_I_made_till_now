print("""
   ____     _   _ U _____ u ____    ____          _____    _   _  U _____ u      _   _       _   _   _   _      __  __     ____  U _____ u   ____     
U /"___|uU |"|u| |\| ___"|// __"| u/ __"| u      |_ " _|  |'| |'| \| ___"|/     | \ |"|   U |"|u| | | \ |"|   U|' \/ '|uU | __")u\| ___"|/U |  _"\ u  
\| |  _ / \| |\| | |  _|" <\___ \/<\___ \/         | |   /| |_| |\ |  _|"      <|  \| |>   \| |\| |<|  \| |>  \| |\/| |/ \|  _ \/ |  _|"   \| |_) |/  
 | |_| |   | |_| | | |___  u___) | u___) |        /| |\  U|  _  |u | |___      U| |\  |u    | |_| |U| |\  |u   | |  | |   | |_) | | |___    |  _ <    
  \____|  <<\___/  |_____| |____/>>|____/>>      u |_|U   |_| |_|  |_____|      |_| \_|    <<\___/  |_| \_|    |_|  |_|   |____/  |_____|   |_| \_\   
  _)(|_  (__) )(   <<   >>  )(  (__))(  (__)     _// \\_  //   \\  <<   >>      ||   \\,-.(__) )(   ||   \\,-.<<,-,,-.   _|| \\_  <<   >>   //   \\_  
 (__)__)     (__) (__) (__)(__)    (__)         (__) (__)(_") ("_)(__) (__)     (_")  (_/     (__)  (_")  (_/  (./  \.) (__) (__)(__) (__) (__)  (__) 



""")
import random

guess_number = random.randint(1,100)
def guess_game(level):
    """Starts game according to level"""
    play_game = True
    if level.lower() == "e":
        chances = 10
    elif level.lower() == "h":
        chances = 5
    else:
        return print("Provide valid input")
    while chances >0:
        print(f"You have {chances} chances!")
        guess = int(input("Guess the number:- "))
        if guess>1 and guess<100:
            chances -=1
            if chances==0 and guess != guess_number:
                print("You lost your all chances 😕")
                play_game = False
                break
            if guess == guess_number:
                print(f"You Guessed it! Answer was {guess_number} ")
                play_game = False
                break
            elif guess > guess_number and play_game:
                print("Too High, Try again")
            elif guess < guess_number and play_game:
                print("Too Low, Try again")
        else:
            print("The number is between 1 and 100 😑")



print(" I am thinking of a number between 1 and 100 and YOU have to guess it")

def guess_game_full():
    """Guess Game"""
    while input("Do you want to play the game? Y/N : ").lower() == "y":
        print(" Let's Start the game!")
        level = input("Select level - Easy (E) / Hard (H) : ")
        guess_game(level)
    else:
        return exit()
while True:
    try:
        guess_game_full()
    except ValueError or NameError:
        print("Please provide valid input")
        input()
