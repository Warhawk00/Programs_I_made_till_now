from turtle import Turtle, Screen, mainloop
tim = Turtle()
screen = Screen()
screen.listen()


def w_control():
    tim.fd(5)


def d_control():
    tim.setheading(tim.heading() - 5)


def a_control():
    tim.setheading(tim.heading() + 5)


def s_control():
    tim.bk(5)


screen.onkeypress(w_control, "w")
screen.onkeypress(s_control, "s")
screen.onkeypress(a_control, "a")
screen.onkeypress(d_control, "d")
screen.onkeypress(tim.reset, "c")
mainloop()