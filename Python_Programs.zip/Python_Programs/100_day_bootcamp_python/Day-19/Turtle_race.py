import turtle as t
import random as r
color_of_racers = ["red", "yellow", "green", "blue", "orange", "purple"]
screen = t.Screen()
race_is_on = False
user_input = screen.textinput(title="choose color", prompt= f"Who will win the race choose the color from{color_of_racers} ")

racers = []
y = -150
i = 0
for i in range(6):
    racer = t.Turtle()
    racer.shape("turtle")
    racer.penup()
    racer.color(color_of_racers[i])
    racer.goto(x=-280, y=y)
    racers.append(racer)
    y += 60
    i += 1
if user_input in color_of_racers:
    race_is_on = True

while race_is_on:
    for racer in racers:
        fd = r.randint(5,10)
        racer.fd(fd)
        if racer.xcor() == 240:
            race_is_on = False
            winner = racer.pencolor()

if winner == user_input:
    print(f"You won! {winner} won")
else:
    print(f"You lost! {winner} won")

screen.screensize(canvwidth=400, canvheight=500)
t.mainloop()