import turtle
import pandas

writer = turtle.Turtle()
writer.penup()
writer.hideturtle()
screen = turtle.Screen()
screen.title("Guess Indian States")
screen.setup(600, 708)
screen.bgpic("india_map.gif")
score = 0
answered = []
data = pandas.read_csv("Data.csv")
while True:
    user_input = screen.textinput(title=f"{score}/28 states guessed", prompt="What is name of next state? ").title()
    if user_input in answered:
        pass
    elif user_input in list(data["State_name"]) and score < 28 :
        score += 1
        x = data[data["State_name"] == user_input]["x"]
        y = data[data["State_name"] == user_input]["y"]
        answered.append(user_input)
        writer.goto(float(x), float(y))
        writer.write(user_input)
    elif user_input == "Exit":
        break
    if score == 28:
        turt = turtle.Turtle()
        turt.penup()
        turt.hideturtle()
        turt.goto(150, 200)
        turt.write("YOU GUESSED ALL")
        screen.exitonclick()
state = data["State_name"].to_list()
for a in answered:
    state.remove(a)
if len(state) > 0:
    state_to_learn = pandas.DataFrame(state)
    state_to_learn.to_csv("States To learn.csv")
