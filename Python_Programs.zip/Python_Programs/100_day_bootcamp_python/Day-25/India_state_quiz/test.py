import turtle
screen = turtle.Screen()

turtle1 = turtle.Turtle()
import pandas
l = [(-74.0, -146.0),
        (200.0, 150.0),
        (193.0, 115.0),
        (67.0, 94.0),
        (-15.0, -6.0),
        (-175.0, -138.0),
        (-226.0, 34.0),
        (-131.0, 160.0),
        (-120.0, 225.0),
        (30.0, 40.0),
        (-160.0, -161.0),
        (-140.0, -248.0),
        (-92.0, 35.0),
        (-156.0, -46.0),
        (229.0, 80.0),
        (160.0, 85.0),
        (213.0, 38.0),
        (242.0, 110.0),
        (47.0, -17.0),
        (-146.0, 206.0),
        (-184.0, 120.0),
        (117.0, 130.0),
        (-90.0, -239.0),
        (-80.0, -86.0),
        (182.0, 55.0),
        (-66.0, 123.0),
        (-90.0, 197.0),
        (93.0, 45.0),

]
state_name = []
with open("co-ordinate.txt") as states:
        state = states.readlines()
        for a in state:
                i = a.strip()
                state_name.append(i)
print(state_name)
dic = {"State_name": state_name, "co-ord" : l}
df = pandas.DataFrame(dic)
df.to_csv("Data.csv")
turtle1.penup()
turtle1.speed(0)
for i in l:
        turtle1.goto(i)
        k = l.index(i)
        turtle1.write(state_name[k])
turtle.mainloop()