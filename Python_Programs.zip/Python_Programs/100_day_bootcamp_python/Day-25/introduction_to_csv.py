import pandas
data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data_20240116.csv")
fur = data["Primary Fur Color"]
fur_color_count = pandas.DataFrame(fur.value_counts())
fur_color_count.to_csv("fur_color_count.csv")