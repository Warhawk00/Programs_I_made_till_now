import time
from turtle import Screen, mainloop
from Snake import Snake, SEG
from food import Food
from score_board import ScoreBoard
screen = Screen()
screen.bgcolor("black")
screen.title("Snake Game")
screen.setup(height=600, width=600)
snake = Snake()
food = Food()
screen.listen()
screen.tracer(0)
screen.onkeypress(snake.up, "Up")
screen.onkeypress(snake.down, "Down")
screen.onkeypress(snake.left, "Left")
screen.onkeypress(snake.right, "Right")
food.refresh()
score_board = ScoreBoard()
game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()
    score_board.show_score()
    if snake.head.distance(food) < 18:
        food.refresh()
        snake.extend()
        score_board.add_score()
    if snake.head.xcor() > 280 or snake.head.ycor() > 300 or snake.head.xcor() < -300 or snake.head.ycor() <-280:
        score_board.game_over()
        game_is_on = False
    for segment in SEG[1::]:
        if snake.head.distance(segment) < 15:
            game_is_on = False
            score_board.game_over()

mainloop()
