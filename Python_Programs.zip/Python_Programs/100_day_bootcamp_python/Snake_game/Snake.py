from turtle import Turtle
SEG = []
SEGMENT_POSITION = [(0,0) , (-20,0) , (-40,0)]

class Snake:
    def __init__(self):
        for position in SEGMENT_POSITION:
            self.add_segment(position)
        self.head = SEG[0]

    def add_segment(self, position):
        segment = Turtle()
        segment.penup()
        segment.color("white")
        segment.shape("square")
        segment.goto(position)
        SEG.append(segment)

    def extend(self):
        self.add_segment(SEG[-1].position())
    def move(self):
        for i in range(len(SEG) - 1 , 0, -1):
            x_cor = SEG[i - 1].xcor()
            y_cor = SEG[i - 1].ycor()
            SEG[i].goto(x_cor, y_cor)
        SEG[0].fd(20)

    def up(self):
        if SEG[0].heading() != 270:
            SEG[0].setheading(90)

    def down(self):
        if SEG[0].heading() != 90:
            SEG[0].setheading(270)

    def right(self):
        if SEG[0].heading() != 180:
            SEG[0].setheading(0)

    def left(self):
        if SEG[0].heading() != 0:
            SEG[0].setheading(180)

