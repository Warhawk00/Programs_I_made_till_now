from turtle import Turtle
from random import randint


class Food(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.shapesize(0.5, 0.5)
        self.color("blue")
        self.speed(0)
        self.penup()
        self.refresh()

    def refresh(self):
        x_cor = randint(-280, 280)
        y_cor = randint(-260, 280)
        self.teleport(x_cor, y_cor)
