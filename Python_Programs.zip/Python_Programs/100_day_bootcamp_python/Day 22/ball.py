from turtle import Turtle
MOVE = [10 ,10]

class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("white")
        self.penup()
    def move(self):
        if self.ycor() > 280:
            MOVE[0] = -10
        elif self.ycor() < -280:
            MOVE[0] = 10
        new_x = self.xcor() + MOVE[1]
        new_y = self.ycor() + MOVE[0]
        self.goto(new_x, new_y)

    def bounce_r(self):
        MOVE[1] = -10
    def bounce_l(self):
        MOVE[1] = 10