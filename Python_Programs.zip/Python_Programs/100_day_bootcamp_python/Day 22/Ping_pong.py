from turtle import Screen, mainloop, Turtle
from paddle import Paddle
from ball import Ball
import time
from Score_board import ScoreBoard
screen = Screen()
screen.bgcolor("black")
screen.setup(800,600)
screen.tracer(0)
r_paddle = Paddle((350, 0))
l_paddle = Paddle((-350,0))

screen.listen()
refresh = True
screen.onkeypress(r_paddle.move_up, "Up")
screen.onkeypress(r_paddle.move_down, "Down")
screen.onkeypress(l_paddle.move_up, "w")
screen.onkeypress(l_paddle.move_down, "s")
screen.tracer(1)
ball = Ball()
score = ScoreBoard()
speed = 0.1
while True:
    screen.update()
    time.sleep(speed)
    ball.move()
    if ball.distance(r_paddle) < 50 and ball.xcor() > 320:
        speed *= 0.7
        ball.bounce_r()
    elif ball.distance(l_paddle) < 50 and ball.xcor() < -320:
        speed *= 0.7
        ball.bounce_l()
    if ball.xcor() > 400:
        score.lscore()
        speed = 0.1
        ball.teleport(0, 0)
        ball.bounce_r()
    elif ball.xcor() < -400:
        score.rscore()
        speed = 0.1
        score.r_score += 1
        ball.teleport(0, 0)
        ball.bounce_l()


