import time
from turtle import Screen, mainloop
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
player = Player()
screen.listen()
screen.onkeypress(player.move, "w")
cars = []
for i in range(30):
    car = CarManager()
    cars.append(car)
game_is_on = True
score = Scoreboard()
while game_is_on:
    time.sleep(0.1)
    screen.update()
    for car in cars:
        car.move()
        if car.distance(player) < 20:
            score.game_over()
            game_is_on = False
        if car.xcor() < -300:
            car.refresh()
    if player.ycor() > 280:
        for car in cars:
            car.speed_up()
        score.increase_lvl()
        player.restart()
mainloop()