from turtle import Turtle
from random import randint, choice
COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 5


class CarManager(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("square")
        self.shapesize(1, 2)
        self.penup()
        self.velocity = STARTING_MOVE_DISTANCE
        self.refresh()


    def move(self):
        self.goto(self.xcor()-self.velocity, self.ycor())

    def speed_up(self):
        self.velocity += MOVE_INCREMENT
    def refresh(self):
        self.goto(randint(300, 1000), randint(-240, 280))
        self.color(choice(COLORS))