with open("C:/Users/MAA/Desktop/niyati.html") as file:
    print(file.read())
