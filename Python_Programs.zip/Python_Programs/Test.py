import prettytable
a = prettytable.PrettyTable()
a.add_column("Pokemon",["Pikachu","Squirtle","Charmendor"])
a.add_column("Type",["Electric","Water","Fire"])
a.align = "l"
print(a)